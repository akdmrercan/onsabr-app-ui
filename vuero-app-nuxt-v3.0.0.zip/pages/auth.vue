<template>
  <AuthLayout>
    <NuxtPage />
  </AuthLayout>
</template>
