<template>
  <AuthLayout>
    <RouterView />
  </AuthLayout>
</template>
