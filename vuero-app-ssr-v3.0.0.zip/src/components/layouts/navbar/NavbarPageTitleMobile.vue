<template>
  <div class="page-title has-text-centered">
    <div class="title-wrap">
      <slot />
    </div>

    <div class="toolbar mobile-toolbar">
      <slot name="toolbar" />
    </div>
  </div>
</template>
