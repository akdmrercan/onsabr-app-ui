/* eslint-disable @typescript-eslint/consistent-type-imports */

declare interface Window {
  ipcRenderer: import('electron').IpcRenderer
}
